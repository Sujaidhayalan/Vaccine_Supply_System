serverName = "DESKTOP-4THPVIL\SQLEXPRESS"
databaseName = "VaccineProductionV1"
connString = 'Driver={SQL Server};Server='+serverName+';Integrated_Security=true;Database='+databaseName